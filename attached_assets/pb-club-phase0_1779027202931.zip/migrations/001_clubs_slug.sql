-- =============================================================================
-- Phase 0 Migration: Tenant slug for clubs
-- Run in Supabase SQL editor. Idempotent — safe to re-run.
-- =============================================================================

-- 1. Add slug column (nullable first so backfill can run; tightened in step 4)
ALTER TABLE clubs
  ADD COLUMN IF NOT EXISTS slug TEXT;

-- 2. Backfill PB Club with 'pb-club'.
--    Hardcoded by id to be explicit and safe — this is the one and only
--    existing club. New clubs choose their slug at onboarding.
UPDATE clubs
SET slug = 'pb-club'
WHERE id = 'c8976e15-e002-4619-bb4b-b1a70f5cd7ab'
  AND slug IS NULL;

-- 3. Verify backfill before tightening constraints.
--    If this fails the migration aborts and we investigate.
DO $$
DECLARE
  null_count INT;
BEGIN
  SELECT COUNT(*) INTO null_count FROM clubs WHERE slug IS NULL;
  IF null_count > 0 THEN
    RAISE EXCEPTION 'Migration aborted: % club row(s) still have NULL slug. Backfill them manually before re-running.', null_count;
  END IF;
END $$;

-- 4. Tighten: NOT NULL + uniqueness + format check.
--    Pattern allows lowercase letters, digits, and hyphens (no leading/trailing
--    hyphen). 2–32 chars. Matches the dashboard's onboarding validation.
ALTER TABLE clubs
  ALTER COLUMN slug SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'clubs_slug_unique'
  ) THEN
    ALTER TABLE clubs ADD CONSTRAINT clubs_slug_unique UNIQUE (slug);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'clubs_slug_format'
  ) THEN
    ALTER TABLE clubs ADD CONSTRAINT clubs_slug_format
      CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$');
  END IF;
END $$;

-- 5. Index for slug lookup (the dashboard hits this on every page load
--    via the URL :slug param)
CREATE INDEX IF NOT EXISTS idx_clubs_slug ON clubs (slug);

-- 6. Grants. New columns inherit from ALTER DEFAULT PRIVILEGES set during
--    the 2026-05-06 hardening, but re-asserting here is cheap insurance.
GRANT SELECT ON clubs TO anon;
GRANT ALL ON clubs TO service_role;

-- 7. Smoke test — verify the row looks right
DO $$
DECLARE
  pb_slug TEXT;
BEGIN
  SELECT slug INTO pb_slug FROM clubs WHERE id = 'c8976e15-e002-4619-bb4b-b1a70f5cd7ab';
  IF pb_slug IS DISTINCT FROM 'pb-club' THEN
    RAISE EXCEPTION 'Smoke test failed: expected slug=pb-club, got %', pb_slug;
  END IF;
  RAISE NOTICE 'Migration complete. PB Club slug = %', pb_slug;
END $$;
