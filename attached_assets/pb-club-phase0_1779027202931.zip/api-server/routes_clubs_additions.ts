/**
 * Clubs routes — list and lookup for the dashboard.
 *
 * GET /api/clubs        → list all clubs (id, slug, name, timezone)
 * GET /api/clubs/:slug  → single club by slug, used on dashboard mount
 *
 * No auth in Phase 0 — these are anon-readable. Auth comes in Phase 0.5.
 *
 * Note: existing /api/clubs/:id/settings PATCH (in routes/clubs.ts per the
 * RUNBOOK write-paths table) must keep working. This file ADDS routes; do
 * not remove existing handlers.
 */

import { Router, type Request, type Response } from "express";
import { supabase } from "../lib/supabaseClient";

const router = Router();

// GET /api/clubs — list all clubs
router.get("/", async (_req: Request, res: Response) => {
  const { data, error } = await supabase
    .from("clubs")
    .select("id, slug, name, timezone")
    .order("name", { ascending: true });

  if (error) {
    res.status(500).json({ error: error.message });
    return;
  }
  res.json({ clubs: data ?? [] });
});

// GET /api/clubs/by-slug/:slug — single club by slug (mount BEFORE :id route
// in your router, or the :id matcher will swallow it)
router.get("/by-slug/:slug", async (req: Request, res: Response) => {
  const slug = req.params.slug;
  if (!/^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$/.test(slug)) {
    res.status(400).json({ error: "Invalid slug format" });
    return;
  }
  const { data, error } = await supabase
    .from("clubs")
    .select("id, slug, name, timezone, scheduled_sync_time, platform")
    .eq("slug", slug)
    .maybeSingle();

  if (error) {
    res.status(500).json({ error: error.message });
    return;
  }
  if (!data) {
    res.status(404).json({ error: "Club not found", slug });
    return;
  }
  res.json({ club: data });
});

export default router;
