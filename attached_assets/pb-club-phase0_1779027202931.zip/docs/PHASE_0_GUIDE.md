# Phase 0 Application Guide — Multi-Tenant Plumbing

**Goal:** turn `CLUB_ID` from a hardcoded constant into a request-scoped value, without changing user-facing behavior for PB Club. After Phase 0, the codebase is ready for a second club to be added by data alone, with zero further code changes.

**What ships in Phase 0:**

1. `clubs.slug` column with `pb-club` backfilled
2. API server: `clubResolver.ts` lib + `requireClub` middleware + updated `/api/clubs` routes
3. Every existing API route audited and updated to scope by `clubId` from the request
4. Dashboard: `ClubContext` + `ClubSwitcher` + `/c/:slug/*` URL pattern
5. Every dashboard Supabase query scoped by `clubId` from context
6. Every `CLUB_ID` constant deleted
7. RUNBOOK.md updated to close open item #14 and document new rules

**What explicitly does NOT ship in Phase 0:**

- User authentication (deferred to Phase 0.5)
- Per-tenant RLS policies (stays uniform `anon SELECT *` — tenant isolation is in the API server layer)
- Capacity fields on `clubs` (deferred to Phase 1 per your decision)
- Multi-tenant UI for messages/templates/agent runs (works automatically once `clubId` is in scope)

---

## Step-by-step

### Step 1 — Run the migration

Open Supabase SQL editor for project `knblhxfwvebxntoshiqm`. Paste and run `migrations/001_clubs_slug.sql`. Expected output ends with `NOTICE: Migration complete. PB Club slug = pb-club`.

Verify in Table Editor that `clubs.slug = 'pb-club'` for the existing row.

### Step 2 — API server: add the new files

Two new files into `artifacts/api-server/src/`:

- `lib/clubResolver.ts` — paste the contents of `api-server/clubResolver.ts`
- The `/api/clubs` additions — open `routes/clubs.ts` (existing file) and add the `GET /` and `GET /by-slug/:slug` handlers from `api-server/routes_clubs_additions.ts`. Mount the new handlers BEFORE any existing `/:id` handler in the same router, or the `:id` matcher will swallow `/by-slug`.

If `routes/clubs.ts` doesn't exist yet (only `PATCH /api/clubs/:id/settings` is referenced in the runbook write-paths table), create it now and register it in `routes/index.ts`:

```typescript
import clubsRouter from "./clubs";
router.use("/clubs", clubsRouter);
```

### Step 3 — API server: audit every existing route

For each file in `artifacts/api-server/src/routes/*.ts`, find and replace the "implicit single club" pattern. The signal to look for is any of:

- `const CLUB_ID = "c8976e15-..."` constant
- `.from("clubs").select(...).limit(1).maybeSingle()` or `.single()`
- A Supabase query against `players`, `attendances`, `messages`, `conversations`, `level_taxonomy`, `level_confidence`, `buddy_pairs`, `monthly_recaps`, `player_milestones`, `session_feedback`, `pending_sends`, `programs`, `message_templates`, `jobs`, or `job_logs` that does NOT include `.eq("club_id", ...)` or doesn't already constrain through a player join

Run this grep in the repo root to size the work:

```bash
grep -rn "CLUB_ID\|\.from(\"clubs\")\.select.*limit(1)\|\.maybeSingle()\|\.single()" artifacts/api-server/src/routes/
grep -rn "CLUB_ID" artifacts/api-server/src/
```

The expected count of `CLUB_ID` references will tell you the scope. The runbook says "several places"; my estimate is 5–15 sites.

**For each route handler**, apply this pattern:

**Before:**
```typescript
router.get("/players", async (req, res) => {
  const { data, error } = await supabase
    .from("players")
    .select("*")
    .order("last_visit_date", { ascending: false });
  ...
});
```

**After:**
```typescript
import { requireClub, type ClubScopedRequest } from "../lib/clubResolver";

router.get("/players", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  const { data, error } = await supabase
    .from("players")
    .select("*")
    .eq("club_id", clubId)       // ← added
    .order("last_visit_date", { ascending: false });
  ...
});
```

**Tables that need `.eq("club_id", clubId)` direct filter:**
- `players`, `attendances`, `conversations`, `messages`, `level_taxonomy`, `programs`, `message_templates`, `clubs` (when listing)

**Tables that filter transitively through `player_id`** (already scoped because the player is club-scoped, BUT still add an explicit join check where possible to prevent cross-tenant leakage if a `player_id` is ever passed in from the request):
- `level_confidence`, `buddy_pairs`, `monthly_recaps`, `player_milestones`, `session_feedback`, `pending_sends`

For these, when the route accepts a `player_id` from the URL or body, validate that player belongs to the resolved club:

```typescript
const { data: player } = await supabase
  .from("players")
  .select("id, club_id")
  .eq("id", playerId)
  .eq("club_id", clubId)         // ← prevents cross-tenant access
  .maybeSingle();
if (!player) {
  res.status(404).json({ error: "Player not found in this club" });
  return;
}
```

**Tables that are NOT club-scoped (no change needed):**
- `jobs`, `job_logs` — operationally global. Job names like `nightly_sync` will need to become per-club later (e.g. `nightly_sync:pb-club`), but that's a Phase 0.5 concern. Document it but don't refactor now.

**The agent route specifically (`routes/agent.ts`):**
- This is the hot path. The runbook gives detailed timing baselines. The change is minimal — add `requireClub` middleware, derive `clubId` from request, then everywhere it currently fetches the player's row, add `.eq("club_id", clubId)`. The cross-tenant guard above is essential here.
- The `social-graph` and `level-confidence` calls inside the route should inherit `clubId` and pass it down.

**Nightly chain (`lib/scheduler.ts`, batch jobs):**
- These run server-side without a request. They need to iterate over ALL clubs, not the implicit one. After Phase 0:
  ```typescript
  const { data: clubs } = await supabase.from("clubs").select("id, slug, timezone");
  for (const club of clubs) {
    // existing logic, scoped to this club.id
  }
  ```
- Each club's `scheduled_sync_time` and `timezone` already exist on the clubs row, so the scheduler tick logic naturally fans out.

### Step 4 — Dashboard: install the context

Two new files into `artifacts/dashboard/src/`:

- `lib/ClubContext.tsx` — paste from `dashboard/ClubContext.tsx`
- `components/ClubSwitcher.tsx` — paste from `dashboard/ClubSwitcher.tsx`

### Step 5 — Dashboard: rewire routing in App.tsx

The current `App.tsx` (per past chats) has routes like `/`, `/players`, `/messages`, `/assessments`, `/settings`. They become `/c/:slug/*`:

```typescript
import { ClubProvider, useClubStatus } from "./lib/ClubContext";

function ClubLayout() {
  const ctx = useClubStatus();
  if (ctx.status === "loading") return <div>Loading club…</div>;
  if (ctx.status === "not_found")
    return <div>Club "{ctx.slug}" not found.</div>;
  if (ctx.status === "error") return <div>Error: {ctx.error}</div>;
  // status === "ready" — render the dashboard shell + outlet
  return <Sidebar /> /* + <Outlet /> for nested routes */;
}

<BrowserRouter>
  <Routes>
    <Route path="/" element={<RootRedirect />} />
    <Route
      path="/c/:slug"
      element={
        <ClubProvider>
          <ClubLayout />
        </ClubProvider>
      }
    >
      <Route index element={<Navigate to="dashboard" replace />} />
      <Route path="dashboard" element={<Dashboard />} />
      <Route path="players" element={<Players />} />
      <Route path="messages" element={<Messages />} />
      <Route path="assessments" element={<Assessments />} />
      <Route path="settings" element={<Settings />} />
      <Route path="session-feedback" element={<SessionFeedback />} />
    </Route>
    <Route path="*" element={<div>Not found</div>} />
  </Routes>
</BrowserRouter>
```

`RootRedirect` component — if there's exactly one club, redirect to it; otherwise show a club picker:

```typescript
function RootRedirect() {
  const [clubs, setClubs] = useState<ClubListItem[] | null>(null);
  useEffect(() => {
    fetch("/api/clubs").then(r => r.json()).then(b => setClubs(b.clubs ?? []));
  }, []);
  if (!clubs) return <div>Loading…</div>;
  if (clubs.length === 0) return <div>No clubs configured.</div>;
  if (clubs.length === 1) return <Navigate to={`/c/${clubs[0].slug}/dashboard`} replace />;
  return <ClubPicker clubs={clubs} />;
}
```

### Step 6 — Dashboard: audit every Supabase query

This is the bulk of the dashboard work. For each `.tsx` file under `artifacts/dashboard/src/`, search for direct Supabase queries:

```bash
grep -rn "supabase\.from(" artifacts/dashboard/src/
```

For each call:

1. Replace `.from("clubs").select(...).limit(1)` patterns with `useClub()` from context
2. Add `.eq("club_id", clubId)` to every query against a club-scoped table
3. Gate the entire `useEffect` on `clubId` being present:

```typescript
const club = useClub();
useEffect(() => {
  let cancelled = false;
  supabase
    .from("players")
    .select("*")
    .eq("club_id", club.id)        // ← added
    .order("last_visit_date", { ascending: false })
    .then(({ data }) => {
      if (!cancelled && data) setPlayers(data);
    });
  return () => { cancelled = true; };
}, [club.id]);                     // ← added to dep array
```

The May 1 fix to `Players.tsx` + `PlayerDrawer.tsx` is the canonical pattern. The rest of the dashboard mirrors it.

**For API calls (fetch to `/api/*`):** use `clubApiUrl(slug, '/api/players')` from `ClubContext.tsx` so the slug is appended automatically.

### Step 7 — Sidebar: drop in the switcher

In `Sidebar.tsx`, add `<ClubSwitcher />` at the top, above the nav items. The component handles the case of only one club (renders a static label, no dropdown) so PB Club's experience doesn't change visually until a second club is added.

Nav item `to=""` props need to become relative to the current club path. Easiest approach: use react-router's relative `<Link>` semantics — `<Link to="players">` inside a `/c/:slug` route resolves to `/c/<slug>/players`. Or use the `useClubStatus()` hook to build absolute paths.

### Step 8 — Final cleanup

Run:

```bash
grep -rn "c8976e15-e002-4619-bb4b-b1a70f5cd7ab" artifacts/
grep -rn "CLUB_ID" artifacts/
```

Both should return zero matches. If anything remains, it's a missed site.

### Step 9 — Test

1. Hit `/` in the dashboard → should redirect to `/c/pb-club/dashboard`
2. Every page loads with PB Club data, exactly as before
3. Hit `/c/nonexistent/dashboard` → should render "Club not found"
4. In Supabase, insert a test second club:
   ```sql
   INSERT INTO clubs (id, slug, name, timezone, platform)
   VALUES (gen_random_uuid(), 'test-club', 'Test Club', 'America/New_York', 'podplay');
   ```
   Hit `/c/test-club/dashboard` → should render empty (no players yet) without errors. `ClubSwitcher` should now show a dropdown with both clubs.
5. Delete the test club:
   ```sql
   DELETE FROM clubs WHERE slug = 'test-club';
   ```

### Step 10 — Update the runbook

In `RUNBOOK.md`:

- Close open item #14 (mark as done with date)
- Add a new "Architectural rules" entry:

  > **Every API route is club-scoped.** No route may use the "first/only club" pattern. The active club is resolved by `lib/clubResolver.ts` from `?clubId=<uuid>` or `?slug=<slug>` on the request. Routes use the `requireClub` middleware; handlers read `clubId` from the request object.

- Add to the schema export: `clubs.slug TEXT NOT NULL UNIQUE`, format-checked

- Document the dashboard URL convention: `/c/:slug/*`

---

## Things that will surface during the audit

A few patterns that didn't get attention in past chats but might exist:

- **Hardcoded timezone** — if any code uses `"America/New_York"` directly instead of `clubs.timezone`, that's now a multi-tenant bug. Should already be sourced from `clubs.timezone` per the runbook, but worth grepping.
- **Hardcoded club name** — labels like "PB Club" in headers, email subjects, or SMS templates. These should pull from `clubs.name`.
- **TCPA window assumptions** — the 8am–7:30pm weekday window in `sanitizeScheduledSendAt` is US-law-based. If a future club is outside the US this changes. Document the assumption; don't refactor yet.
- **Hardcoded PodPlay subdomain** — `https://pbclub.podplay.app` likely appears in some sync code. If it does, that's not on `clubs` yet. Adding a `podplay_subdomain` column to `clubs` is a Phase 0 candidate if you want — let me know.

If any of these come up during the grep, flag them and I'll write the patch.

---

## Why Phase 0 leaves anon-key read access in place

A reasonable question: "if we're going multi-tenant, shouldn't the dashboard authenticate, so club operators only see their own club?"

Yes — eventually. But Phase 0 keeps the door open:

- **The data model is ready.** `clubs.slug` is in the URL; the API server validates it; pages scope queries to it. Adding auth is purely additive.
- **The risk surface in Phase 0 is the same as today.** The anon key already exposes all club data to anyone who knows it. We're not making it worse.
- **Auth is a deep change.** Sessions, password hashing, login UI, password reset, possibly SSO. Doing it well takes longer than the analytics features we want to ship. Doing it badly is worse than waiting.

Phase 0.5 is the auth phase. Phase 1 (heatmap) and Phase 2 (insights) can ship before or after auth — they're independent.

That said: do **not** point the public internet at this dashboard between Phase 0 and Phase 0.5. Until auth lands, it should stay behind whatever access control Replit provides, a VPN, or an HTTP basic-auth proxy.

---

## Files in this Phase 0 bundle

- `migrations/001_clubs_slug.sql` — paste into Supabase SQL editor
- `api-server/clubResolver.ts` → save to `artifacts/api-server/src/lib/clubResolver.ts`
- `api-server/routes_clubs_additions.ts` → merge into `artifacts/api-server/src/routes/clubs.ts`
- `dashboard/ClubContext.tsx` → save to `artifacts/dashboard/src/lib/ClubContext.tsx`
- `dashboard/ClubSwitcher.tsx` → save to `artifacts/dashboard/src/components/ClubSwitcher.tsx`
- `docs/PHASE_0_GUIDE.md` — this file
