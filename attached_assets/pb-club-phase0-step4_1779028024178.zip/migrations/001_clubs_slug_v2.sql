-- =============================================================================
-- Phase 0 Migration (v2): Tenant slug + platform subdomain for clubs
-- Run in Supabase SQL editor. Idempotent — safe to re-run.
--
-- v2 changes over v1:
--   - Adds platform_subdomain column so the PodPlay base URL stops being
--     hardcoded as "pbclub.podplay.app" across 9 files. Replit's grep found
--     this; Phase 0 should fix it now rather than ship multi-tenant code
--     that pretends to be tenant-aware but still hits one subdomain.
-- =============================================================================

-- 1. Add slug column (nullable first so backfill can run; tightened in step 4)
ALTER TABLE clubs
  ADD COLUMN IF NOT EXISTS slug TEXT;

-- 2. Add platform_subdomain column.
--    For PodPlay clubs: the part before .podplay.app (e.g. "pbclub").
--    Nullable for now — clubs on other platforms won't have one. We can
--    rename to platform_host or extend later if non-PodPlay platforms enter.
ALTER TABLE clubs
  ADD COLUMN IF NOT EXISTS platform_subdomain TEXT;

-- 3. Backfill PB Club.
UPDATE clubs
SET slug = 'pb-club',
    platform_subdomain = 'pbclub'
WHERE id = 'c8976e15-e002-4619-bb4b-b1a70f5cd7ab'
  AND (slug IS NULL OR platform_subdomain IS NULL);

-- 4. Verify slug backfill before tightening constraints.
DO $$
DECLARE
  null_count INT;
BEGIN
  SELECT COUNT(*) INTO null_count FROM clubs WHERE slug IS NULL;
  IF null_count > 0 THEN
    RAISE EXCEPTION 'Migration aborted: % club row(s) still have NULL slug.', null_count;
  END IF;
END $$;

-- 5. Tighten slug: NOT NULL + uniqueness + format check.
ALTER TABLE clubs
  ALTER COLUMN slug SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'clubs_slug_unique'
  ) THEN
    ALTER TABLE clubs ADD CONSTRAINT clubs_slug_unique UNIQUE (slug);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'clubs_slug_format'
  ) THEN
    ALTER TABLE clubs ADD CONSTRAINT clubs_slug_format
      CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$');
  END IF;
END $$;

-- 6. Format check for platform_subdomain (when present).
--    DNS-safe label: lowercase letters, digits, hyphens; 1–63 chars.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'clubs_platform_subdomain_format'
  ) THEN
    ALTER TABLE clubs ADD CONSTRAINT clubs_platform_subdomain_format
      CHECK (
        platform_subdomain IS NULL
        OR platform_subdomain ~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$'
      );
  END IF;
END $$;

-- 7. Indexes
CREATE INDEX IF NOT EXISTS idx_clubs_slug ON clubs (slug);

-- 8. Grants (idempotent insurance)
GRANT SELECT ON clubs TO anon;
GRANT ALL ON clubs TO service_role;

-- 9. Smoke tests
DO $$
DECLARE
  pb_slug TEXT;
  pb_sub  TEXT;
BEGIN
  SELECT slug, platform_subdomain INTO pb_slug, pb_sub
  FROM clubs
  WHERE id = 'c8976e15-e002-4619-bb4b-b1a70f5cd7ab';

  IF pb_slug IS DISTINCT FROM 'pb-club' THEN
    RAISE EXCEPTION 'Smoke test failed: expected slug=pb-club, got %', pb_slug;
  END IF;
  IF pb_sub IS DISTINCT FROM 'pbclub' THEN
    RAISE EXCEPTION 'Smoke test failed: expected platform_subdomain=pbclub, got %', pb_sub;
  END IF;
  RAISE NOTICE 'Migration v2 complete. PB Club slug=%, platform_subdomain=%', pb_slug, pb_sub;
END $$;
