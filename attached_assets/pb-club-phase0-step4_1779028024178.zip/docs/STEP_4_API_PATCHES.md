# Phase 0 — Step 4: Concrete File Patches

Based on the grep output, here are the exact changes per file. Apply in the order listed. The order matters — later files depend on earlier ones.

---

## Pre-flight: re-run the migration (v2)

The original migration was never executed. Use `migrations/001_clubs_slug_v2.sql` (in this bundle) instead of v1 — it adds `clubs.platform_subdomain` in the same shot so we don't need a second migration to fix the 11 hardcoded `pbclub.podplay.app` sites.

Run in Supabase SQL editor. Expected final output:

```
NOTICE: Migration v2 complete. PB Club slug=pb-club, platform_subdomain=pbclub
```

Confirm before proceeding.

---

## File 1: `artifacts/api-server/src/routes/clubs.ts`

The grep showed this file already exists (one hit for the PATCH settings handler). Open it and add the two GET handlers from `routes_clubs_additions.ts`. They go above any existing `/:id`-based route. After your additions the route registration should look approximately like:

```typescript
router.get("/", async (_req, res) => { /* list */ });
router.get("/by-slug/:slug", async (req, res) => { /* lookup */ });
// ... existing handlers ...
router.patch("/:id/settings", async (req, res) => { /* existing */ });
```

If `routes/clubs.ts` is not registered in `routes/index.ts`, add:

```typescript
import clubsRouter from "./clubs";
router.use("/clubs", clubsRouter);
```

---

## File 2: `artifacts/api-server/src/routes/players.ts`

Two issues per the grep:

- Line 100: `const CLUB_ID = "c8976e15-..."`
- Line 213: `.eq("club_id", "c8976e15-...")` — bare UUID, even worse

**Patch:**

At the top of the file, add:
```typescript
import { requireClub, type ClubScopedRequest } from "../lib/clubResolver";
```

Delete line 100 (`const CLUB_ID = ...`).

For every route handler defined in this file, add `requireClub` as middleware:

```typescript
// Before
router.get("/", async (req, res) => { ... });

// After
router.get("/", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  ...
});
```

Apply the same to PATCH/POST handlers in this file.

Find every `CLUB_ID` reference (lines 105 and the bare UUID at 213) and replace with `clubId` (the local variable from the request).

After this file: a final grep `grep -n "CLUB_ID\|c8976e15" artifacts/api-server/src/routes/players.ts` should return zero matches.

---

## File 3: `artifacts/api-server/src/routes/onboarding.ts`

Worth a careful read before changing — onboarding is the one route that legitimately operates *before* a club is fully wired up. Three hits per grep:

- Line 7: `const CLUB_ID = process.env.CLUB_ID ?? "c8976e15-..."`
- Lines 17, 162: `.eq("id", CLUB_ID)`
- Line 170: logging `club_id: CLUB_ID`

**Decision:** in Phase 0 we don't have a multi-club onboarding flow yet. Two reasonable paths:

**Option A (recommended for Phase 0):** Keep onboarding scoped to a club identified by `?slug=` like every other route. The flow becomes: a club row is inserted manually (via SQL or admin); onboarding completes its configuration by slug.

**Option B:** Onboarding becomes the *creation* route — POST `/onboarding/create` inserts a new clubs row, generates a slug, and returns it. Phase 0.5 work; defer.

**For Phase 0, apply Option A:**

```typescript
import { requireClub, type ClubScopedRequest } from "../lib/clubResolver";

// Delete the CLUB_ID constant entirely.

// Every handler gets requireClub:
router.get("/status", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  // ... replace all CLUB_ID with clubId
});

router.post("/complete", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  // ... replace all CLUB_ID with clubId
  req.log.info({ club_id: clubId, /* rest */ }, "Onboarding complete");
});
```

---

## File 4: `artifacts/api-server/src/lib/scheduler.ts` — DO NOT TOUCH YET

The grep shows two hits but this file needs special handling (the nightly chain). Leave it alone in this step. It gets its own dedicated patch later (Step 7) once routes are stable.

---

## File 5: `artifacts/api-server/src/importAllPlayers.js`

This is a `.js` file (one of the three that legitimately manage their own Supabase client per the runbook architectural rules). Three hits:

- Line 11: `const CLUB_ID = "c8976e15-..."`
- Line 264: `.eq("id", CLUB_ID)` — fetches the clubs row for the API key
- Line 353: `club_id: CLUB_ID` — inserts new player rows

This file runs server-side from the scheduler / a manual job, with no HTTP request. It needs `clubId` passed in.

**Patch:** convert the file's main function to accept a `clubId` parameter:

```javascript
// BEFORE
const CLUB_ID = "c8976e15-...";
export async function importAllPlayers() {
  // ... uses CLUB_ID ...
}

// AFTER
export async function importAllPlayers(clubId) {
  if (!clubId) throw new Error("importAllPlayers requires clubId");
  // ... replace all CLUB_ID references with clubId ...
}
```

Also: line 10 has the hardcoded `https://pbclub.podplay.app`. Change to fetch the subdomain from the clubs row (which it's already fetching at line 264 for the API key — just add `platform_subdomain` to the select and use it):

```javascript
const { data: club } = await supabase
  .from("clubs")
  .select("platform_api_key, platform_subdomain, name, timezone")
  .eq("id", clubId)
  .maybeSingle();
if (!club?.platform_subdomain) {
  throw new Error(`Club ${clubId} has no platform_subdomain`);
}
const baseUrl = `https://${club.platform_subdomain}.podplay.app`;
```

Every call site of `importAllPlayers()` must be updated to pass `clubId`. There are at least two — the manual-trigger route in `routes/import.ts` and the scheduler. The scheduler call gets handled in Step 7; for now, find the route that triggers this import manually and add `requireClub` to it so the `clubId` flows through.

---

## File 6: `artifacts/api-server/src/syncEventAttendance.js`

Similar to importAllPlayers. Three hits:

- Line 15: hardcoded `pbclub.podplay.app`
- Line 20: `const CLUB_ID = ...`
- Line 21: `DEFAULT_TIMEZONE` const (has fallback — fine for now)
- Line 213: `.eq("id", CLUB_ID)`

Same pattern: function takes `clubId` parameter, fetches the club row for subdomain/API key/timezone, builds the base URL dynamically.

```javascript
export async function syncEventAttendance(clubId) {
  if (!clubId) throw new Error("syncEventAttendance requires clubId");
  
  const { data: club } = await supabase
    .from("clubs")
    .select("platform_api_key, platform_subdomain, timezone")
    .eq("id", clubId)
    .maybeSingle();
  if (!club) throw new Error(`No club with id=${clubId}`);
  if (!club.platform_subdomain) {
    throw new Error(`Club ${clubId} has no platform_subdomain`);
  }
  
  const baseUrl = `https://${club.platform_subdomain}.podplay.app`;
  const timezone = club.timezone ?? DEFAULT_TIMEZONE;
  
  // ... rest of function uses these locals, not the const CLUB_ID ...
}
```

---

## File 7: `artifacts/api-server/src/fetchAvailablePrograms.js`

Per the grep, has hardcoded subdomain at lines 1–2 AND a hardcoded `"America/New_York"` at line 33. Same pattern as the previous two .js files:

```javascript
export async function fetchAvailablePrograms(clubId) {
  if (!clubId) throw new Error("fetchAvailablePrograms requires clubId");
  
  const { data: club } = await supabase
    .from("clubs")
    .select("platform_api_key, platform_subdomain, timezone")
    .eq("id", clubId)
    .maybeSingle();
  if (!club?.platform_subdomain) throw new Error(`Club ${clubId} missing platform_subdomain`);
  
  const baseUrl = `https://${club.platform_subdomain}.podplay.app`;
  const timezone = club.timezone ?? "America/New_York";  // last-resort fallback only
  // ... rest of function ...
}
```

---

## File 8: `artifacts/api-server/src/importPhoneNumbers.js`

Grep showed hardcoded subdomain at line 8. Same pattern — take `clubId`, fetch subdomain from clubs row, build base URL dynamically.

---

## File 9: `artifacts/api-server/src/lib/postSessionFeedback.ts`

Hardcoded subdomain at line 19. This is a `.ts` file, so it MUST use the shared Supabase client (`lib/supabaseClient`). 

Drop in the new `lib/podplayUrls.ts` helper (provided in this bundle) and use it:

```typescript
import { getPodPlayBaseUrl } from "../lib/podplayUrls";

// Inside the function that needs the URL:
const baseUrl = await getPodPlayBaseUrl(clubId);
const signupUrl = `${baseUrl}/community/events/${eventId}`;
```

Function signature needs to take `clubId` if it doesn't already. The runbook tier 4 list mentions this file as not yet audited — be careful and read the whole file before changing.

---

## File 10: `artifacts/api-server/src/lib/socialGraph.ts`

Hardcoded subdomain at line 6. Same pattern — use the `podplayUrls.ts` helper. The file already takes player context which gives access to club_id; thread it through.

---

## File 11: `artifacts/api-server/src/routes/events.ts`

Two hits per grep (lines 5 and 84). Line 5 is likely a const at module scope. Line 84 is likely in the signup URL construction.

```typescript
import { requireClub, type ClubScopedRequest } from "../lib/clubResolver";
import { getEventSignupUrl } from "../lib/podplayUrls";

// Delete any module-level hardcoded base URL.

router.get("/upcoming", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  // ... existing logic ...
  // For each event, replace hardcoded URL construction with:
  const signupUrl = await getEventSignupUrl(clubId, event.id);
});
```

---

## File 12: `artifacts/api-server/src/routes/socialGraph.ts`

Hardcoded subdomain at line 8. Plus this file currently does the duplicate-PodPlay-fetch dance the runbook flagged (tier 1 open item #2 — refactor to use `lib/socialGraph.ts:getPlayerSocialContext`). For Phase 0, do NOT do the consolidation refactor — just:

1. Add `requireClub` middleware to all routes
2. Replace the hardcoded URL with the helper
3. Defer the consolidation to a future cleanup

---

## File 13: `artifacts/api-server/src/routes/import.ts`

Grep showed one site (line 33): `.from("clubs")` reading name/timezone for logging. Low-risk; just needs `requireClub` and scoping:

```typescript
router.post("/players", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  // ... existing logic, but the importAllPlayers() call needs clubId passed:
  await importAllPlayers(clubId);
  // ... logging change:
  req.log.info({ club_id: clubId }, "Import triggered");
});
```

---

## File 14: All routes NOT touched by grep — still need scoping

The grep was for `CLUB_ID` and bare UUIDs. But these routes are club-scoped data routes that also need `requireClub` middleware even though they don't have explicit `CLUB_ID` references (they currently work because there's only one club and the implicit "all players in the db = pb club's players" assumption holds). Audit each:

- `routes/messages.ts` — every player_id, conversation_id is implicitly PB Club's
- `routes/agent.ts` — DO NOT TOUCH YET (Step 8)
- `routes/sync.ts`
- `routes/templates.ts`
- `routes/feedback.ts`
- `routes/recap.ts` (if exists)
- `routes/socialGraph.ts` — covered above
- Any other route file in `routes/`

For each, the pattern is identical:

```typescript
import { requireClub, type ClubScopedRequest } from "../lib/clubResolver";

router.get("/", requireClub, async (req, res) => {
  const clubId = (req as ClubScopedRequest).clubId;
  const { data } = await supabase
    .from("messages")  // or whichever table
    .select("*")
    .eq("club_id", clubId)  // direct scope, OR transitive via player join with cross-tenant guard
    .order("created_at", { ascending: false });
  ...
});
```

For tables that aren't directly `club_id`-tagged (level_confidence, buddy_pairs, monthly_recaps, etc.) — use the cross-tenant guard pattern from the original guide.

---

## Verification after Step 4

Run these greps. All should return zero matches:

```bash
grep -rn "CLUB_ID" artifacts/api-server/src/
grep -rn "c8976e15-e002-4619-bb4b-b1a70f5cd7ab" artifacts/api-server/src/
grep -rn "pbclub\.podplay\.app" artifacts/api-server/src/
```

The only acceptable remaining hits:
- `lib/scheduler.ts` — handled in Step 7
- `routes/agent.ts` — handled in Step 8

Then TypeScript check:

```bash
cd artifacts/api-server && npx tsc --noEmit
```

Paste results. STOP here and wait for review before moving to dashboard work (Step 5).
