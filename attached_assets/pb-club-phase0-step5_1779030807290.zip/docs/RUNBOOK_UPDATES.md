# Runbook update — append these entries

Apply to `RUNBOOK.md` in the project root.

---

## 1. In the "Audit changelog" section, append a new dated entry

Add this block at the END of the changelog (after the 2026-05-07 entries):

```markdown
### 2026-05-17 — Phase 0: multi-tenant plumbing

Closes open item 14 (multi-tenant readiness). The codebase is now ready 
to serve a second club without further structural code changes — only 
data inserts.

**Schema changes:**

- `clubs.slug TEXT NOT NULL UNIQUE` — URL identifier. PB Club seeded as 
  `'pb-club'`. Format-checked via `clubs_slug_format` constraint: 
  `^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$`.
- `clubs.platform_subdomain TEXT` — nullable. PB Club seeded as `'pbclub'`. 
  Powers PodPlay base URL construction. Format-checked: DNS-safe label, 
  1–63 chars.
- Index `idx_clubs_slug` on `clubs(slug)`.

**New API server modules:**

- `lib/clubResolver.ts` — `resolveClubId()` reads `?clubId=<uuid>` or 
  `?slug=<slug>` from request and validates against the clubs table. 
  `requireClub` Express middleware exposes the resolved id as 
  `(req as ClubScopedRequest).clubId`. 60-second in-memory cache for 
  slug→id lookups.
- `lib/podplayUrls.ts` — `getPodPlayBaseUrl(clubId)` and 
  `getEventSignupUrl(clubId, eventId)` replace hardcoded 
  `https://pbclub.podplay.app` references. Same caching pattern.

**Route changes (API server):**

- Every route that touches club-scoped data now mounts `requireClub`. 
  Affected files: `routes/players.ts`, `routes/onboarding.ts`, 
  `routes/clubs.ts`, `routes/messages.ts`, `routes/sync.ts`, 
  `routes/templates.ts`, `routes/feedback.ts`, `routes/programs.ts`, 
  `routes/recap.ts`, `routes/events.ts`, `routes/socialGraph.ts`, 
  `routes/import.ts`.
- `/api/clubs` GET (list) and `/api/clubs/by-slug/:slug` GET added — 
  consumed by the dashboard's `ClubSwitcher` and `ClubContext`.
- Twilio webhook handlers (`/webhook/inbound`, `/webhook/status`) 
  intentionally do NOT use `requireClub` — see "Known multi-tenant gaps" 
  below.

**JS worker changes:**

- `importAllPlayers.js`, `syncEventAttendance.js`, 
  `fetchAvailablePrograms.js`, `importPhoneNumbers.js` — each now 
  accepts `clubId` as the first positional parameter and fetches 
  `platform_api_key` + `platform_subdomain` from the clubs row at the 
  top of the function. Sync logic, pagination, DUPR pass, win-back 
  detection, and upsert batching are unchanged.
- `fetchAvailablePrograms.js` cache converted from module-level 
  variables to a `Map<clubId, CacheEntry>`. Required for multi-tenant 
  correctness — without it two clubs would clobber each other's 
  program lists.
- `importPhoneNumbers.js` Supabase client switched from anon to 
  service-role key. Pre-existing bug under runbook §"Supabase client 
  usage" rule 4; fixed opportunistically during the audit.

**Dashboard changes:**

- `lib/ClubContext.tsx` — `ClubProvider` reads `:slug` from the URL 
  param and fetches the matching club row. `useClub()`, 
  `useClubStatus()`, `useClubId()`, and `clubApiUrl()` helpers.
- `components/ClubSwitcher.tsx` — sidebar dropdown. Renders a static 
  label when only one club exists.
- URL convention: every page now lives under `/c/:slug/*`. Root `/` 
  redirects to the only-or-first club's slug.

**Files explicitly NOT touched in Phase 0** (deferred to later phases):

- `lib/scheduler.ts` — nightly chain fan-out to all clubs. Step 7.
- `routes/agent.ts` — hot path; patched with extra care. Step 8.

**Architectural rules added:**

> **Every API route is club-scoped.** No route may assume "the only 
> club" or use `from("clubs").select().limit(1)`. The active club is 
> resolved by `lib/clubResolver.ts` from `?clubId=<uuid>` or 
> `?slug=<slug>` on the request. Routes use the `requireClub` 
> middleware; handlers read `clubId` from the request object.
> Exceptions: webhook handlers that have no request-bound club 
> context (see "Known multi-tenant gaps" below).

> **PodPlay base URLs are never hardcoded.** Use 
> `lib/podplayUrls.ts:getPodPlayBaseUrl(clubId)` in `.ts` files. In 
> `.js` workers, build the URL from `clubs.platform_subdomain` after 
> fetching the club row.

**Removed:**

- The `CLUB_ID = "c8976e15-..."` constant in 5 source files. 
- One bare-UUID `.eq("club_id", "c8976e15-...")` in `routes/players.ts`. 
- Hardcoded `"PB Club"` string in `messages.ts:interpolate()`. Club name 
  is now sourced from `clubs.name` once per bulk run.

**Verified after Phase 0:**

- `grep -rn "CLUB_ID" artifacts/api-server/src/` returns only the 
  scheduler.ts and clubResolver.ts (comment) hits.
- `grep -rn "c8976e15" artifacts/` returns zero.
- `grep -rn "pbclub.podplay.app" artifacts/api-server/src/` returns 
  only a comment in podplayUrls.ts.
- `tsc --noEmit` passes cleanly for both api-server and dashboard.
- PB Club end-to-end behavior unchanged.
```

---

## 2. In the "Open follow-up items, prioritized" section, update the list

**Close open item 14** by changing its header line from:

```markdown
**14. Idempotency guard on scheduler tick** (S2) (30 minutes)
```

to:

```markdown
**~~14. Idempotency guard on scheduler tick~~** — see new open item 17.
```

Wait — open item 14 in the runbook is actually the scheduler idempotency item, not the CLUB_ID one. Re-reading: open item 14 in the runbook is "Idempotency guard on scheduler tick." That stays open. The CLUB_ID problem doesn't have its own numbered open item — it's mentioned in the schema export section 4 under "clubs and level_taxonomy" as a parenthetical ("multi-tenant readiness is partial"). That note should be updated.

In `SUPABASE_SCHEMA_EXPORT.md`, find this line in section 4:

```markdown
- `clubs` currently has 1 row. `CLUB_ID = "c8976e15-e002-4619-bb4b-b1a70f5cd7ab"` is hardcoded in several places — multi-tenant readiness is partial.
```

Replace with:

```markdown
- `clubs` currently has 1 row (PB Club, slug `pb-club`). Multi-tenant ready as of 2026-05-17 — the active club is resolved per-request via `lib/clubResolver.ts`. No code path assumes a single club. See RUNBOOK.md audit changelog 2026-05-17.
- `clubs.slug` — URL-safe identifier, `NOT NULL UNIQUE`, format-checked. Used in dashboard URLs `/c/:slug/*` and API params `?slug=`.
- `clubs.platform_subdomain` — nullable, DNS-safe label. PodPlay base URL is constructed as `https://{platform_subdomain}.podplay.app`. Required for clubs on the PodPlay platform.
```

---

## 3. Add three new entries to "Open follow-up items"

Add these at the end of the Tier 2 ("Real-data-dependent") section in `RUNBOOK.md`:

```markdown
### Tier 2 — Real-data-dependent (revisit when second club onboards)

**17. Webhook phone-lookup multi-tenant scope** (2 hours; revisit at 2nd-club onboarding)
The `/webhook/inbound` Twilio handler looks up players by phone with no 
`club_id` scope. Safe today (one club, phone effectively unique). Becomes 
ambiguous when a second club exists, especially if a person belongs to 
both. Fix: route inbound webhooks to the correct club using the `To` 
field (or `MessagingServiceSid`) before the player lookup. Requires 
per-club Twilio numbers/messaging services, which is a Phase 0.5/1 
infrastructure decision. Document the resolution rule in this runbook 
when implemented.

**18. `req.params` typing in `players.ts` and `socialGraph.ts`** (15 minutes)
Express v5 typed `req.params.id` as `string | string[]`. The Phase 0 
patch used `as string` casts (9 spots in `players.ts`, 3 in 
`socialGraph.ts`) which papers over the case of wildcard routes. None 
exist today; if any are added, the cast becomes unsafe. Replace with a 
proper param validator helper when convenient.

**19. `lib/scheduler.ts` multi-club fan-out** (4 hours; depends on this)
The nightly chain currently uses the hardcoded `CLUB_ID` constant — 
deliberately not patched in Phase 0. Convert to iterate over 
`SELECT id, slug, timezone FROM clubs` and run the chain per-club. 
Per-club idempotency guard (item 14) gets revisited here.

**20. `routes/agent.ts` multi-tenant patch** (1 hour; depends on this)
The agent hot path uses the hardcoded `CLUB_ID` constant — deliberately 
not patched in Phase 0. Apply `requireClub` middleware and scope all 
queries by `clubId`. Verify post-patch with the timing baselines in 
this runbook (p50 ≤5.5s, input tokens ≤4500).
```
