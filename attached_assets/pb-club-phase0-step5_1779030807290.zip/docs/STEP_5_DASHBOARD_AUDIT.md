# Phase 0 — Step 5: Dashboard Multi-Tenant Audit

API server is done. Now apply the same multi-tenant pattern to the dashboard.

**What's changing:**

1. Six page files lose their `from("clubs").select(...).limit(1).maybeSingle()` calls and read `clubId` from `useClub()` context instead.
2. `App.tsx` is rewired so every dashboard page lives under `/c/:slug/*`. Root `/` redirects to the active club.
3. `Sidebar.tsx` gets the `ClubSwitcher` at the top, and all nav links become slug-relative.
4. Every `supabase.from(...)` call against a club-scoped table gets `.eq("club_id", club.id)` added.
5. Every `fetch("/api/...")` call gets the `slug` param appended via `clubApiUrl()`.

**What's not changing:**

- Page-internal logic, layouts, styling — untouched.
- The Supabase anon-key dashboard read pattern — stays as-is (auth is Phase 0.5).
- The five lib files / components dropped in earlier — already in place.

---

## Step 5.1 — Rewire `App.tsx`

The current `App.tsx` (per past chats) has routes like:

```typescript
<Routes>
  <Route path="/" element={<Dashboard />} />
  <Route path="/players" element={<Players />} />
  <Route path="/messages" element={<Messages />} />
  <Route path="/assessments" element={<Assessments />} />
  <Route path="/settings" element={<Settings />} />
  <Route path="/session-feedback" element={<SessionFeedback />} />
</Routes>
```

Replace with:

```typescript
import { Routes, Route, Navigate, useParams } from "react-router-dom";
import { ClubProvider, useClubStatus } from "./lib/ClubContext";
import { useEffect, useState } from "react";

// --- Root redirect: if exactly one club exists, redirect to it.
//     If zero, render a fatal error. If multiple, render a picker.
function RootRedirect() {
  const [clubs, setClubs] = useState<
    { id: string; slug: string; name: string }[] | null
  >(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/clubs")
      .then((r) => r.json())
      .then((body: { clubs?: typeof clubs }) => {
        if (cancelled) return;
        setClubs(body.clubs ?? []);
      })
      .catch(() => {
        if (!cancelled) setClubs([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (clubs === null) {
    return <div style={{ padding: 24 }}>Loading…</div>;
  }
  if (clubs.length === 0) {
    return <div style={{ padding: 24 }}>No clubs configured.</div>;
  }
  if (clubs.length === 1) {
    return <Navigate to={`/c/${clubs[0].slug}/dashboard`} replace />;
  }
  // Multi-club picker — minimal, will become a real page in Phase 0.5
  return (
    <div style={{ padding: 24 }}>
      <h2>Select a club</h2>
      <ul>
        {clubs.map((c) => (
          <li key={c.id}>
            <a href={`/c/${c.slug}/dashboard`}>{c.name}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

// --- Layout wrapper for /c/:slug/* routes
//     Gates rendering on the club being resolved before children mount.
function ClubLayout() {
  const ctx = useClubStatus();
  if (ctx.status === "loading") {
    return <div style={{ padding: 24 }}>Loading club…</div>;
  }
  if (ctx.status === "not_found") {
    return (
      <div style={{ padding: 24 }}>
        Club "{ctx.slug}" not found.{" "}
        <a href="/">Pick a different club</a>.
      </div>
    );
  }
  if (ctx.status === "error") {
    return (
      <div style={{ padding: 24 }}>
        Error loading club: {ctx.error}
      </div>
    );
  }
  // status === "ready" — render the dashboard shell.
  // Keep whatever your existing layout component is (Sidebar + content area).
  return <DashboardShell />;
}

// DashboardShell is whatever you currently use to render Sidebar + the
// active route. If you don't have one named that, leave the existing
// Sidebar + main content layout in place — just make sure <Outlet /> is
// where the child routes render.

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route
          path="/c/:slug"
          element={
            <ClubProvider>
              <ClubLayout />
            </ClubProvider>
          }
        >
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="players" element={<Players />} />
          <Route path="messages" element={<Messages />} />
          <Route path="assessments" element={<Assessments />} />
          <Route path="settings" element={<Settings />} />
          <Route path="session-feedback" element={<SessionFeedback />} />
        </Route>
        <Route path="*" element={<div style={{ padding: 24 }}>Not found.</div>} />
      </Routes>
    </BrowserRouter>
  );
}
```

The `DashboardShell` is whatever wrapping component currently holds Sidebar + page content. If the current `App.tsx` already has a wrapping layout, reuse it — just make sure it renders `<Outlet />` from `react-router-dom` where the page content goes.

---

## Step 5.2 — Update Sidebar

In `src/components/Sidebar.tsx`:

1. Add the `ClubSwitcher` at the top:

```typescript
import { ClubSwitcher } from "./ClubSwitcher";
import { useClubStatus } from "../lib/ClubContext";

// Inside the Sidebar component, at the top of the returned JSX:
<aside>
  <ClubSwitcher />
  {/* ... existing nav items below ... */}
</aside>
```

2. Convert every nav `<Link>` from absolute to slug-relative. For example:

```typescript
// BEFORE
<Link to="/players">Players</Link>
<Link to="/messages">Messages</Link>

// AFTER (two equivalent options — pick one)

// Option A: build absolute paths from current slug
const ctx = useClubStatus();
const slug = ctx.status === "ready" ? ctx.club.slug : "";
<Link to={`/c/${slug}/players`}>Players</Link>

// Option B: use relative paths — react-router resolves against the
// current route, which is /c/:slug
<Link to="players">Players</Link>  // resolves to /c/<slug>/players
```

Option B is cleaner if the Sidebar is mounted inside the `/c/:slug` route hierarchy. Use that.

Active-state highlighting (the amber left border per past chats) should compare against the current location's pathname *after* the slug segment:

```typescript
import { useLocation } from "react-router-dom";

const { pathname } = useLocation();
const pageAfterSlug = pathname.split("/").slice(3).join("/") || "dashboard";
// pathname "/c/pb-club/players"  →  pageAfterSlug "players"
// pathname "/c/pb-club"           →  pageAfterSlug "dashboard"

const isActive = (page: string) => pageAfterSlug === page;
```

---

## Step 5.3 — Page-by-page audit

For each of the six pages below, apply the same pattern. The pattern:

1. Add `import { useClub } from "../lib/ClubContext";` at the top.
2. Replace the `from("clubs").select(...).limit(1).maybeSingle()` call entirely. The club data is already in context.
3. Add `.eq("club_id", club.id)` to every Supabase query against `players`, `attendances`, `messages`, `conversations`, `level_taxonomy`, `programs`, `message_templates`.
4. Add `club.id` to the dependency array of every `useEffect` that hits Supabase.
5. For `fetch("/api/...")` calls, import `clubApiUrl` and use it.

The pattern in code (this exact shape appears in every page):

```typescript
// BEFORE — top of page component
const [clubName, setClubName] = useState("");

useEffect(() => {
  let cancelled = false;
  (async () => {
    const { data: clubRow } = await supabase
      .from("clubs")
      .select("name")
      .limit(1)
      .maybeSingle();
    if (cancelled || !clubRow) return;
    setClubName(clubRow.name);
    // ... then load players, messages, etc. ...
    const { data: players } = await supabase
      .from("players")
      .select("*")
      .order("last_visit_date", { ascending: false });
    if (!cancelled) setPlayers(players ?? []);
  })();
  return () => { cancelled = true; };
}, []);

// AFTER
import { useClub, clubApiUrl } from "../lib/ClubContext";

const club = useClub();   // safe — ClubLayout gates render on status==="ready"

useEffect(() => {
  let cancelled = false;
  (async () => {
    const { data: players } = await supabase
      .from("players")
      .select("*")
      .eq("club_id", club.id)
      .order("last_visit_date", { ascending: false });
    if (!cancelled) setPlayers(players ?? []);
  })();
  return () => { cancelled = true; };
}, [club.id]);

// Anywhere clubName was used in the page — use club.name directly.
```

### Specific files

**`pages/Assessments.tsx`** (line 114)
- Delete the `from("clubs").select("name").limit(1)` call.
- Replace `clubName` state with `club.name` from context.
- Audit all Supabase queries — add `.eq("club_id", club.id)` to any against the club-scoped tables.

**`pages/Dashboard.tsx`** (line 304, and line 136 for the hardcoded America/New_York)
- Delete the `from("clubs").select("id, name").limit(1)` call.
- Use `club.name` and `club.id` from context.
- For the hardcoded `"America/New_York"` at line 136 (the date formatter): replace with `club.timezone`. The context exposes timezone.

**`pages/Messages.tsx`** (line 145)
- Same pattern. Note: this page makes API calls to `/api/messages` — wrap those in `clubApiUrl(club.slug, ...)`.

**`pages/Players.tsx`** (line 263)
- Already partially fixed in the May 1 chat (clubId state, passed to PlayerDrawer). Now just replace the local `clubId` state with `club.id` from context. Delete the `from("clubs").select(...)` call. The PlayerDrawer prop continues to work — pass `club.id` instead of state.
- The taxonomy fetch in `PlayerDrawer.tsx` is already keyed off the `clubId` prop — leave it.

**`pages/SessionFeedback.tsx`** (line 129)
- Same pattern.

**`pages/Settings.tsx`** (lines 566, 570, 548, 576)
- Two `from("clubs").select(...)` calls — both replaced by `useClub()` context.
- Lines 548, 576 are hardcoded `"America/New_York"` defaults. Replace with `club.timezone`.
- This is the page that PATCHes club settings via `/api/clubs/:id/settings` — make sure the `:id` in the URL uses `club.id` from context, not the state from the now-deleted fetch.

---

## Step 5.4 — Update API call sites

Search the dashboard for `fetch("/api/`:

```bash
grep -rn 'fetch(.*"/api/' artifacts/dashboard/src/
```

For each match where the endpoint is club-scoped (anything except `/api/clubs` listing), use `clubApiUrl`:

```typescript
// BEFORE
const res = await fetch("/api/agent/run", {
  method: "POST",
  body: JSON.stringify({ player_id }),
});

// AFTER
import { clubApiUrl } from "../lib/ClubContext";
const club = useClub();

const res = await fetch(clubApiUrl(club.slug, "/api/agent/run"), {
  method: "POST",
  body: JSON.stringify({ player_id }),
});
```

`clubApiUrl(slug, path, extra?)` appends `?slug=<slug>` (or merges into existing query string). Every API call routes through it — including POST/PATCH/DELETE.

---

## Step 5.5 — Verification

Run these greps. All should return zero matches:

```bash
grep -rn 'from("clubs").select.*limit(1)' artifacts/dashboard/src/
grep -rn 'from(.clubs.).select.*maybeSingle' artifacts/dashboard/src/
grep -rn '"c8976e15-' artifacts/dashboard/src/
grep -rn '"America/New_York"' artifacts/dashboard/src/
```

The last one (timezone) may return a hit in `lib/ClubContext.tsx` if you've added it as a fallback — that's fine if it's inside a clearly-marked "last resort" path. Better: no fallback, fail loud, so we notice if a club row is missing timezone.

Then TypeScript:

```bash
cd artifacts/dashboard && npx tsc --noEmit
```

Should be clean.

Then runtime smoke test:

1. Restart the dashboard dev server.
2. Hit `/` → should redirect to `/c/pb-club/dashboard`.
3. Every page should load PB Club data exactly as before.
4. Hit `/c/nonexistent/dashboard` → should render "Club not found".
5. Insert a test club:
   ```sql
   INSERT INTO clubs (id, slug, platform_subdomain, name, timezone, platform)
   VALUES (gen_random_uuid(), 'test-club', 'testclub', 'Test Club',
           'America/Los_Angeles', 'podplay');
   ```
6. Refresh — `ClubSwitcher` should now show a dropdown with both clubs.
7. Switch to "Test Club" — every page should render empty (no players) without errors.
8. Switch back to "PB Club" — data returns.
9. Delete the test club:
   ```sql
   DELETE FROM clubs WHERE slug = 'test-club';
   ```

If anything fails, paste the error.

---

## What to report back

After Step 5.1–5.2: tsc clean, App.tsx + Sidebar in place.
After Step 5.3: tsc clean, all 6 pages patched.
After Step 5.4: grep results showing zero direct fetches without `clubApiUrl`.
After Step 5.5: runtime smoke test results.

Then STOP. We move to Step 6 (small cleanup pass for any remaining `America/New_York` and lib-level hardcodes), then Step 7 (scheduler fan-out), then Step 8 (agent route).
